const logregBox = document.querySelector('.logreg-box');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');

if (loginLink && registerLink) {
    registerLink.addEventListener('click', () => {
        logregBox.classList.add('active'); // Add active class to show the registration form
    });

    loginLink.addEventListener('click', () => {
        logregBox.classList.remove('active'); // Remove active class to show the login form
    });
}
