document.getElementById("confirm-logout").addEventListener("click", function() {
    window.location.href = "login-register.html"; // Redirect to login page
});

document.getElementById("cancel-logout").addEventListener("click", function() {
    window.location.href = "home.html"; // Redirect back to home if user cancels
});
